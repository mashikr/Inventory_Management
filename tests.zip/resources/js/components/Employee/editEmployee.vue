<template>
    <div class="row px-lg-5 mx-lg-4">
        <div class="card mt-3 shadow">
            <div class="card-header text-center">
                <h3>Update Employee</h3>
            </div>
            <div class="card-body">
                <form enctype='multipart/form-data' @submit.prevent="editEmployee">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="username">Name</label>
                                <input type="text" name="name" class="form-control" v-model="form.name" required>
                                <div class="text-danger" v-if="errors.name">{{ errors.name[0] }}</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" class="form-control" v-model="form.email" required>
                                <div class="text-danger" v-if="errors.email">{{ errors.email[0] }}</div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" name="address" v-model="form.address" id="address" required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="salary">Salary</label>
                                <input type="number" class="form-control" name="salary" v-model="form.salary" min="1" id="salary" required>                            
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="joining_date">Joining Date</label>
                                <input type="date" class="form-control" name="joining_date"  v-model="form.joining_date" id="joining_date" required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nid">NID</label>
                                <input type="text" class="form-control" name="nid" v-model="form.nid" id="nid" required>                            
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone_no">Phone No</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text py-0 text-dark" id="basic-addon1">+880</span>
                                    </div>
                                    <input type="number" class="form-control" name="phone_no"  v-model="form.phone" id="phone_no" min="1000000000" required>
                                </div>
                                <div class="text-danger" v-if="errors.phone">{{ errors.phone[0] }}</div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="image">Image</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" @change="addImage" class="custom-file-input" id="image">
                                    <label class="custom-file-label" for="image">{{ fileName }}</label>
                                </div>  
                            </div>
                        </div>
                        <div class="col-md-6">
                            <img :src="form.photo" alt="Selected Photo"  height="80px">
                        </div>
                    </div>
                    
                    <input type="submit" name="submit" class="btn btn-primary mt-2" value="Submit">
                </form>

            </div>
        </div>
    </div>
</template>


<script>
    export default {
         created() {
            if(!User.loggedIn()) {
                this.$router.push({name: '/'});
            }
            axios.get("/api/employee/show/"+this.$route.params.id)
            .then(response => this.form = response.data)
            .catch(error => Notification.error(error.response.data.message))
        },
        data() {
            return {
                form: {
                    name: null,
                    email: null,
                    address: null,
                    salary: null,
                    joining_date: null,
                    nid: null,
                    phone: null,
                    photo: null,
                },
                fileName: 'Chose Photo',
                errors: {}
            }
        },
        methods: {
            editEmployee() {
               axios.patch('/api/employee/edit/'+this.$route.params.id, this.form)
               .then((response) => {
                   this.$router.push({ name: 'allEmployee'});
                   Notification.success();
               })
               .catch(error => {
                   Notification.error(error.response.data.message);
               })
            },
            addImage(event) {
                let file = event.target.files[0];
                this.fileName = file.name;
                const fileExt = ["jpg", "jpeg", "JPG", "png", "PNG"];
                let ext = this.fileName.split(".");
                ext = ext[ext.length-1];
                if (file.size>1048770) {
                    Notification.image_validation('Upload image less than 1MB');
                } else if(!fileExt.includes(ext)) {
                     Notification.image_validation('Please insert an image file');
                } else {
                    let reader = new FileReader();
                    reader.onload = event => {
                        this.form.photo = event.target.result;
                    }
                    reader.readAsDataURL(file);
                }
            }
        }
    }
</script>