/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue').default;

import VueRouter from 'vue-router'
Vue.use(VueRouter)

import { routes } from './router.js';
const router = new VueRouter({
    routes,
    mode: 'history'
  })

import User from './helpers/User';
window.User = User;

// Sweetalert 
import Swal from 'sweetalert2'
window.Swal = Swal;

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})
window.Toast = Toast;

// Noty
window.Noty = require('noty');

// Import Notification
import Notification from './helpers/Notification.js';
window.Notification = Notification;

const app = new Vue({
    el: '#app',
    router,
});
